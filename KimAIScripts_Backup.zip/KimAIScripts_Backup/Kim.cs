using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class Kim : CharacterController
{
    [SerializeField] float ContextRadius;
    [SerializeField] float speed = 5f;

    private Pathfinding pathfinding;
    private List<PathNode> currentPath;
    private int currentPathIndex;

    private Transform currentTarget; //either burger or exit
    private List<Transform> collectedBurgers = new List<Transform>();
    private bool foundAllBurgers = false;

    public override void StartCharacter()
    {
        base.StartCharacter();
        pathfinding = GetComponent<Pathfinding>();  // reminder: attach pathfinding to Kim
    }

    public override void UpdateCharacter()
    {
        base.UpdateCharacter();

        //if all burgers are collected move to exit
        if (foundAllBurgers)
        {
            MoveToExit();
        }
        else 
        {
            //check for zombies
            Zombie closestZombie = GetClosest(GetContextByTag("Zombie"))?.GetComponent<Zombie>();
            if (closestZombie != null)
            {
                FleeFromZombie(closestZombie); //flees zombies
            }
            else 
            {
                FindAndCollectBurgers(); // i mean
            }
        }
        MoveAlongPath(); // update movement along current path
    }

    Vector3 GetEndPoint()
    {
        return Grid.Instance.WorldPos(Grid.Instance.GetFinishTile());
    }

    GameObject[] GetContextByTag(string aTag)
    {
        Collider[] context = Physics.OverlapSphere(transform.position, ContextRadius);
        List<GameObject> returnContext = new List<GameObject>();
        foreach (Collider c in context)
        {
            if (c.transform.CompareTag(aTag))
            {
                returnContext.Add(c.gameObject);
            }
        }
        return returnContext.ToArray();
    }

    GameObject GetClosest(GameObject[] aContext)
    {
        float dist = float.MaxValue;
        GameObject Closest = null;
        foreach (GameObject z in aContext)
        {
            float curDist = Vector3.Distance(transform.position, z.transform.position);
            if (curDist < dist)
            {
                dist = curDist;
                Closest = z;
            }
        }
        return Closest;
    }
    void FleeFromZombie(Zombie zombie)
    { 
        Vector3 fleeDirection = (transform.position - zombie.transform.position).normalized;
        Vector3 safePosition = transform.position + fleeDirection * 2f; //find a safe spot 2 units away
        currentPath = pathfinding.FindPath(
            (int)transform.position.x, 
            (int)transform.position.y,
            (int)safePosition.x,
            (int)safePosition.y);
        currentPathIndex = 0; //start to run along the new path
    }

    void FindAndCollectBurgers() 
    {
        Transform burger = GetClosest(GetContextByTag("Burger"))?.transform; // find closest borgir
        if (burger != null && !collectedBurgers.Contains(burger))
        {
            currentTarget = burger;
            currentPath = pathfinding.FindPath(
                (int)transform.position.x,
                (int)transform.position.y,
                (int)burger.position.x,
                (int)burger.position.y); // get path to borger
            currentPathIndex = 0;  // Start moving along the path
        }
        //check if all burgers are collected
        if (collectedBurgers.Count == GetContextByTag("Burger").Length)
        { 
            foundAllBurgers = true;
        }
    }

    void MoveAlongPath()
    {
        if (currentPath == null || currentPathIndex >= currentPath.Count) return;

        //get current path node as vector2int
        Vector2Int currentPos = new Vector2Int(currentPath[currentPathIndex].x, currentPath[currentPathIndex].y);

        //retrieve corresponding tile from grid
        Grid.Tile tile = Grid.Instance.TryGetTile(currentPos);

        //check if tile exist
        if (tile != null)
        {
            Vector3 targetPosition = Grid.Instance.WorldPos(tile);
            float step = speed * Time.deltaTime;

            //Move towards target node
            transform.position = Vector3.MoveTowards(transform.position, targetPosition, step);

            //if current node is reached move to next
            if (Vector3.Distance(transform.position, targetPosition) < 0.1f)
            {
                currentPathIndex++; //move to next node in path
            }

            //if target is burger collect it
            if (currentTarget != null && Vector3.Distance(transform.position, currentTarget.position) < 1f)
            {
                if (!collectedBurgers.Contains(currentTarget))
                {
                    collectedBurgers.Add(currentTarget); // collect burg
                    Debug.Log("Yummy!");
                }
            }
        }
        else 
        {
            Debug.LogError("Tile not found for position: " + currentPos);
        }
    }

    void MoveToExit() 
    {
        Vector3 exitPosition = GetEndPoint();
        currentPath = pathfinding.FindPath(
            (int)transform.position.x,
            (int)transform.position.y,
            (int)exitPosition.x,
            (int)exitPosition.y); // get path to exit
            currentPathIndex = 0;  // Start moving along the path

    }
}
