using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices.WindowsRuntime;
using UnityEngine;
using UnityEngine.Tilemaps;

public class Pathfinding : MonoBehaviour
{
    private const int Move_Straight_Cost = 10;
    private const int Move_Diagonal_Cost = 14;
    private Grid grid;
    private Dictionary<Grid.Tile, PathNode> pathNodeMap;
    private List<PathNode> openList;
    private List<PathNode> closedList;


    public Pathfinding(int width, int height) 
    {
        grid = Grid.Instance;

        pathNodeMap = new Dictionary<Grid.Tile, PathNode>();

        foreach (Grid.Tile tile in grid.GetTiles()) 
        {
            pathNodeMap[tile] = new PathNode(grid, tile.x, tile.y);
        }        
    }

    public List<PathNode> FindPath(int startX, int startY, int endX, int endY)
    {


        Grid.Tile startTile = grid.TryGetTile(new Vector2Int(startX, startY));
        Grid.Tile endTile = grid.TryGetTile(new Vector2Int(endX, endY));

        // Check if start or end nodes are valid
        if (startTile == null || endTile == null)
        {
            return null; // or handle the error appropriately
        }

        PathNode startNode = pathNodeMap[startTile];
        PathNode endNode = pathNodeMap[endTile];


        openList = new List<PathNode> { startNode };
        closedList = new List<PathNode>();

        for (int x = 0; x < grid.GetWidth(); x++) 
        {
            for (int y = 0; y < grid.GetHeight(); y++) 
            {
                PathNode pathNode = pathNodeMap[grid.TryGetTile(new Vector2Int(x, y))];
                if (pathNode == null)
                {
                    pathNode.gCost = int.MaxValue;
                    pathNode.CalculateFCost();
                    pathNode.cameFromNode = null;
                }
            }
        }

        startNode.gCost = 0;
        startNode.hCost = CalculateDistanceCost(startNode, endNode);
        startNode.CalculateFCost();

        while (openList.Count > 0)
        {
            PathNode currentNode = GetLowestFCostNode(openList);
            if (currentNode == endNode) 
            {
                return CalculatePath(endNode);
            }
            
            openList.Remove(currentNode);
            closedList.Add(currentNode);

            foreach (PathNode neighborNode in GetNeighborList(currentNode))
            {
                if (closedList.Contains(neighborNode)) continue;
                
                int tentativeGCost =  currentNode.gCost + CalculateDistanceCost(currentNode, neighborNode);
                if (tentativeGCost < neighborNode.gCost)
                {
                    neighborNode.cameFromNode = currentNode;
                    neighborNode.gCost = tentativeGCost;
                    neighborNode.hCost = CalculateDistanceCost(neighborNode, endNode);
                    neighborNode.CalculateFCost();

                    if (!openList.Contains(neighborNode))
                    { 
                        openList.Add(neighborNode);
                    }
                }
            }
        }

        //out of nodes on openlist
        return null;
    }



    private List<PathNode> GetNeighborList(PathNode currentNode) 
    {
        List<PathNode> neighborList = new List<PathNode>();
        if (currentNode.x - 1 >= 0)
        {//left
            neighborList.Add(GetNode(currentNode.x - 1, currentNode.y));
         //left down
            if (currentNode.y - 1 >= 0) neighborList.Add(GetNode(currentNode.x - 1, currentNode.y - 1));
         //left up
            if (currentNode.y + 1 < grid.GetHeight()) neighborList.Add(GetNode(currentNode.x - 1, currentNode.y + 1));
        }
        if (currentNode.x + 1 < grid.GetWidth())
        {//right
            neighborList.Add(GetNode(currentNode.x + 1, currentNode.y));
         //right down
            if (currentNode.y - 1 >= 0) neighborList.Add(GetNode(currentNode.x + 1, currentNode.y - 1));
         //right up
            if (currentNode.y + 1 < grid.GetHeight()) neighborList.Add(GetNode(currentNode.x + 1, currentNode.y + 1));
        }
        if (currentNode.y - 1 >=0) neighborList.Add(GetNode(currentNode.x, currentNode.y -1));
        //down
        if (currentNode.y + 1 < grid.GetHeight()) neighborList.Add(GetNode(currentNode.x, currentNode.y + 1));
        //up
        return neighborList;
    }

    private PathNode GetNode(int x, int y)
    {
        Grid.Tile tile = grid.TryGetTile(new Vector2Int(x, y));
        if (tile != null && pathNodeMap.ContainsKey(tile))
        {
            return pathNodeMap[tile];
        }
        return null;
    }

    private List<PathNode> CalculatePath(PathNode endNode)
    {
        List<PathNode> path = new List<PathNode>();
        path.Add(endNode);
        PathNode currentNode = endNode;
        while (currentNode.cameFromNode != null)
        { 
            path.Add(currentNode.cameFromNode);
            currentNode = currentNode.cameFromNode;
        }
        path.Reverse();
        return path;
    }

    private int CalculateDistanceCost(PathNode a, PathNode b)
    {
        int xDistance = Mathf.Abs(a.x - b.x);
        int yDistance = Mathf.Abs(a.y - b.y);
        int remaining = Mathf.Abs(xDistance - yDistance);
        return Move_Diagonal_Cost * Mathf.Min(xDistance, yDistance) + Move_Straight_Cost * remaining;
    }

    private PathNode GetLowestFCostNode(List<PathNode> pathNodeList)
    {
        PathNode lowestFCostNode = pathNodeList[0];
        for (int i = 1; i < pathNodeList.Count; i++)
        {
            if (pathNodeList[i].fCost < lowestFCostNode.fCost)
            {
                lowestFCostNode = pathNodeList[i];
            }
        }
        return lowestFCostNode;
    }

}
